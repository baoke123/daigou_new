from page.app.app import App


class TestDaigou():
    '''
    搜索并取消搜索商品，删除历史搜索记录
    '''
    def test1(self):
        assert App().start().goto_market().goto_searchGoods().searchGoods("测试").cancelSearchGoods().goto_searchGoods().deleteHistorySearch()
    '''
    收藏并取消收藏商品
    '''
    def test2(self):
        assert App().start().goto_market().goto_swipeup_market().goto_goodsDetail().collect().cancelCollect()
    '''
    把商品加入购物袋，结算后，取消支付，在我的订单页面，立即付款，取消支付，再取消订单，删除订单。
    '''
    def test3(self):
        assert App().start().goto_market().goto_swipeup_market().goto_swipeup_market().goto_goodsDetail().addtoShoppingbag().goto_shoppingbag().settle().checkAddressAndAdd("test1", "13111111111", "address").payimmediately().cancelPaymentAndBacktoMyOrderInPersonalCenter().payimmediatelyInMyOrder().cancelPaymentAndBacktoMyOrderInPersonalCenter().cancelOrder().deleteOrder()

    '''
    把商品加入购物车，结算后，取消支付，在我的订单页面打开订单详情页，立即付款，并取消支付，在订单详情页，取消订单
    '''
    def test4(self):
        assert App().start().goto_market().goto_swipeup_market().goto_swipeup_market().goto_goodsDetail().addtoShoppingbag().goto_shoppingbag().settle().checkAddressAndAdd("test1", "13111111111", "address").payimmediately().cancelPaymentAndBacktoMyOrderInPersonalCenter().goto_OrderDetailInPersonCt().payimmediatelyInOrderDetail().backtoOrderDetailInPersonalCt().cancelOrder()
    '''
    判断是否有浏览记录，有浏览记录，先清空浏览记录再浏览商品，没有浏览记录，浏览商品，并检验商品是否显示在浏览记录里
    '''
    def test5(self):
        assert App().start().goto_market().goto_personalcenter().goto_browserHistory().checkAndClearRecords().goto_backtoPersonalCenter().goto_market().goto_swipeup_market().goto_goodsDetail().goto_swipeup_goodsDetail().getGoodsDescriptionFromMarket().backto_market().goto_personalcenter().goto_browserHistory().goto_goodsDetail().goto_swipeup_goodsDetail().getGoodsDescriptionFromBrowserHistory().checkGoodsDescription()
    '''
    把商品加入购物车，在浏览记录里删除浏览记录
    '''
    def test6(self):
        assert App().start().goto_market().goto_swipeup_market().goto_goodsDetail().backto_market().goto_personalcenter().goto_browserHistory().deleteBrowserHistroy()
    '''
    把商品加入收藏，在我的收藏里删除商品
    '''
    def test7(self):
        assert App().start().goto_market().goto_swipeup_market().goto_goodsDetail().collect().backto_market().goto_personalcenter().goto_collectGoods().deleteCollectedGoods()
    '''
    在我的收藏里判断是否有商品，有商品，先清空商品，再收藏商品，没有商品，收藏商品，在我的收藏里删除商品
    '''
    def test8(self):
        assert App().start().goto_market().goto_personalcenter().goto_collectGoods().checkAndDeleteCollectedGoods().goto_quguangguang().goto_swipeup_market().goto_swipeup_market().goto_goodsDetail().goto_swipeup_goodsDetail().collect().backto_market().goto_personalcenter().goto_collectGoods().deleteCollectedGoods()