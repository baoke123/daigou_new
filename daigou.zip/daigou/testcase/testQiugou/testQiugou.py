from page.app.app import App


class TestQiugou():
    '''
    搜索求购，并取消搜索，删除历史搜索记录
    '''
    def test(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_searchQiugou().searchQiugou("测试").cancelSearchQiugou().goto_searchQiugou().deleteHistorySearchForQiugou()
    '''
    检验话题链接跳转页面是否正确
    '''
    def test1(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDetail").goto_swipedown_publishQiugouFinish().viewxuqiu().goto_swipeup_qiugouDetail().getTopiclink().goto_topicpage().getTopiclink().checkTopiclink()

    '''
    发布求购，并校验浏览量是否正确
    '''
    def test2(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().backtoQiugou().checkQiugou().goto_checkViewnum()
    '''
    发布求购，返回求购，打开求购详情，编辑求购
    '''
    def test3(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().backtoQiugou().checkQiugou().goto_editQiugou().editQiugou("editQiugoudescription")

    '''
    发布求购，返回求购，打开求购详情，关闭求购
    '''
    def test4(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().backtoQiugou().checkQiugou().goto_closeQiugou().closeQiugou()

    '''
    发布求购，返回求购，打开求购详情，删除求购
    '''
    def test5(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().backtoQiugou().checkQiugou().goto_deleteQiugou().deleteQiugou()

    '''
    发布求购，查看需求，编辑需求
    '''
    def test6(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().viewxuqiu().goto_editQiugou().editQiugou("editQiugoudescription")

    '''
    发布求购，查看需求，关闭需求
    '''
    def test7(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().viewxuqiu().goto_closeQiugou().closeQiugou()

    '''
    发布求购，查看需求，删除需求
    '''
    def test8(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("qiugouDescription").goto_swipedown_publishQiugouFinish().viewxuqiu().goto_deleteQiugou().deleteQiugou()

    '''
    保存图片
    '''
    def test9(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_qiugouDetail().savePicture()

    '''
    举报求购
    '''
    def test10(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().goto_reportQiugou().reportQiugou("no reason")

    '''
    点赞并取消点赞
    '''
    def test11(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_qiugouDetail().dianzan().cancelDianzan()

    '''
    点赞，并在赞过里校验是否存在
    '''
    def test12(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_qiugouDetail().dianzan().getDescriptionFromQiugouList().goto_backtoQiugou().goto_mine().goto_swipeup_mine().goto_zanguo().goto_qiugouDetail().goto_swipeup_qiugouDetail().getDescriptionFromZanguo().checkQiugouInZanguo()

    '''
    接单并取消接单
    '''
    def test13(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().goto_jiedan().jiedan("no description", "1").cancelJiedan()

    '''
    接单，并在我的接单里检验是否存在
    '''
    def test14(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().goto_swipeup_qiugouDetail().getDescriptionFromQiugouList().goto_jiedan().jiedan("description", "1").goto_backtoQiugou().goto_mine().goto_jiedanInMine().goto_myJiedan().goto_qiugouDetail().goto_swipeup_qiugouDetail().getDescriptionFromMyJiedan().checkQiugouInMyJiedan()

    '''
    在求购详情里修改商品价格，检验在求购详情页面是否显示正确
    '''
    def test15(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().goto_jiedan().jiedan("baobeiDescription", "1").findoutModifyprice().goto_modifyprice().modifypriceInQiugouDetail("123").getModifiedprice().checkModifiedpriceInQiugouDetail()

    '''
    接单后，在我的接单里取消接单
    '''
    def test16(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().getDescriptionFromQiugouList().goto_jiedan().jiedan("baobeiDescription", "1").goto_backtoQiugou().goto_mine().goto_jiedanInMine().goto_myJiedan().cancelJiedan().checkCancelJiedan()

    '''
    接单，在我的接单里修改商品价格，并检验修改后的价格是否正确
    '''
    def test17(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_swipeup_qiugou().goto_qiugouDetail().goto_jiedan().jiedan("baobeiDescription", "1").goto_backtoQiugou().goto_mine().goto_jiedanInMine().goto_myJiedan().goto_modifyprice().modifyprice("123").goto_qiugouDetail().goto_swipeup_qiugouDetail().goto_swipeup_qiugouDetail().checkModifiedprice()

    '''
    发布，点赞，删除求购，在赞过里清空失效需求
    '''
    def test18(self):
        assert App().start().goto_privatedOrder().goto_qiugou().goto_publishQiugou().publishQiugou("description").goto_swipedown_publishQiugouFinish().backtoQiugou().goto_mine().goto_myorder().goto_QiugouDetail().goto_closeQiugou().closeQiugouAndBacktoMyOrder().goto_swipedown_myorder().checkInvalidXuqiu()