from page.app.app import App
class TestBaobei():
    '''
    搜索并取消搜索宝贝，删除历史搜索记录
    '''
    def test(self):
        assert App().start().goto_privatedOrder().goto_searchBaobei().searchBaobei("测试").cancelSearchBaobei().goto_searchBaobei().deleteHistorySearchForBaobei()
    '''
    打开私人订制，发布宝贝，编辑宝贝，下架宝贝，重新发布宝贝，在宝贝管理里编辑宝贝，下架宝贝，在下架宝贝列表里删除宝贝
    '''
    def test1(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobei("title1", "decription1", "1", "1").goto_baobeiDetail().goto_editBaobei().editBaobei("title2", "description2", "2", "2").goto_undercarriageBaobei().undercarriageBaobei().goto_republishBaobei().republishBaobei("title3", "description3", "3", "3").goto_privatedOrder().goto_mine().goto_jiedanInMine().goto_baobeiManage().goto_editBaobei().editBaobeiInBaobeiManage("title4", "description4", "4", "4").goto_undercarriageBaobei().undercarriageBaobeiInBaobeiManage().goto_undercarriageBaobeiList().deleteBaobei()

    '''
    打开私人订制，发布宝贝，编辑宝贝，下架宝贝，重新发布宝贝，在宝贝管理里编辑宝贝，下架宝贝，在下架宝贝列表里重新发布宝贝
    '''
    def test2(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobei("title1", "decription1", "1", "1").goto_baobeiDetail().goto_editBaobei().editBaobei("title2", "description2", "2", "2").goto_undercarriageBaobei().undercarriageBaobei().goto_republishBaobei().republishBaobei("title3", "description3", "3", "3").goto_privatedOrder().goto_mine().goto_jiedanInMine().goto_baobeiManage().goto_editBaobei().editBaobeiInBaobeiManage("title4", "description4", "4", "4").goto_undercarriageBaobei().undercarriageBaobeiInBaobeiManage().goto_undercarriageBaobeiList().republishBaobei("title5", "description5", "5", "5")


    '''
    打开私人订制，发布宝贝，编辑宝贝，删除宝贝，重新发布宝贝，在宝贝管理里编辑宝贝，删除宝贝
    '''
    def test3(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobei("title1", "description1", "1", "1").goto_baobeiDetail().goto_editBaobei().editBaobei("title2", "description2", "2", "2").goto_deleteBaobei().deleteBaobei().goto_republishBaobei().republishBaobei("title3", "description3", "3", "3").goto_privatedOrder().goto_mine().goto_jiedanInMine().goto_baobeiManage().goto_editBaobei().editBaobeiInBaobeiManage("title4", "description4", "4", "4").goto_deleteBaobei().deleteBaobeiInManage()


    '''
    在宝贝详情里点赞宝贝后，校验是否在我的-赞过里存在
    '''
    def test4(self):
        assert App().start().goto_privatedOrder().goto_mine().goto_swipeup_mine().goto_zanguo().goto_baobei().checkAndDeleteAllBaobei().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().dianzan().goto_privatedOrder().goto_mine().goto_zanguo().goto_baobei().checkBaobei()

    '''
    宝贝加入购物车，并在购物车中结算，在确认订单页面立即支付，取消支付后，在订单详情页支付，取消支付，在订单详情页删除订单
    '''
    def test5(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().addtoShoppingcart().goto_privatedOrder().goto_shoppingcart().settle().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().payimmediately().cancelPayment().closeKeyboard().cancelOrder().closeKeyboard().deleteOrder()

    '''
    宝贝加入购物车，并在购物车中结算，在确认订单页面立即支付，取消支付后，在订单详情页取消支付，并删除订单。
    '''
    def test6(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().addtoShoppingcart().goto_privatedOrder().goto_shoppingcart().settle().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().cancelOrder().deleteOrder()

    '''
    在商品详情页立即购买并结算，在确认订单页立即支付，取消支付后，在订单详情页立即支付，取消支付，并取消订单，删除订单
    '''
    def test7(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().checkBaobei().buyimmediately().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().payimmediately().cancelPayment().closeKeyboard().cancelOrder().closeKeyboard().deleteOrder()

    '''
    在商品详情页立即购买并结算，在确认订单页立即支付，取消支付后，在订单详情页取消订单并删除订单
    '''
    def test8(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().checkBaobei().buyimmediately().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().cancelOrder().deleteOrder()
    '''
    将多个宝贝加入购物车，结算并取消支付后，跳转到商品订单页
    '''
    def test111(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().addtoShoppingcart().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().addtoShoppingcart().goto_privatedOrder().goto_shoppingcart().settle().checkAddressAndAdd("name1", "13111111111", "address1").payimmediately().cancelPaymentAndBacktoGoodsOrder().checkGoodsOrder()
    '''
    宝贝详情页举报宝贝
    '''
    def test9(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().goto_report().report("description")

    '''
    宝贝详情页保存图片
    '''
    def test10(self):
        assert App().start().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().savePicture()

    '''
    先清空商品订单列表中的待付款订单，再购买宝贝并在商品订单列表立即付款并取消订单，在商品订单列表里删除订单
    '''
    def test11(self):
        assert App().start().goto_privatedOrder().goto_mine().goto_goodsOrderList().goto_topayment().goto_checkAndClearAllOrders().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().checkBaobei().buyimmediately().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().goto_baobeiDetail().goto_privatedOrder().goto_mine().goto_goodsOrderList().goto_topayment().payimmediately().cancelPaymentAndBacktoTopayment().cancelOrder().goto_goodsOrderList().deleteOrder()


    '''
    先清空商品订单列表中的待付款订单，再购买宝贝并在商品订单列表立即付款并取消订单，在订单详情里删除订单
    '''
    def test12(self):
        assert App().start().goto_privatedOrder().goto_mine().goto_goodsOrderList().goto_topayment().goto_checkAndClearAllOrders().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().checkBaobei().buyimmediately().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().goto_baobeiDetail().goto_privatedOrder().goto_mine().goto_goodsOrderList().goto_topayment().payimmediately().cancelPaymentAndBacktoTopayment().cancelOrder().goto_goodsOrderList().goto_OrderDetail().deleteOrder()

    '''
    先清空商品订单列表中待付款订单，清空购物车，点击去逛逛，搜索宝贝后将宝贝加入购物车，结算，付款并取消支付，删除订单
    '''
    def test13(self):
        assert App().start().goto_privatedOrder().goto_mine().goto_goodsOrderList().goto_topayment().goto_checkAndClearAllOrders().goto_privatedOrder().goto_switchupBaobeiList().goto_baobeiDetail().checkBaobei().addtoShoppingcart().goto_privatedOrder().goto_shoppingcart().goto_shoppingcartDownSwipe().clearShoppingcart().clickquguangguang().goto_searchBaobei().searchBaobei("哈哈哈").goto_baobeiDetail().checkBaobei().addtoShoppingcart().goto_privatedOrderFromBaobeiDetailsearched().goto_shoppingcart().goto_shoppingcartDownSwipe().settleBaobeiSearched().checkAddressAndAdd("name1", "13111111111", "address").payimmediately().cancelPayment().cancelOrder().deleteOrder()

    '''
    创建商品标签为海外好物的宝贝并在推荐列表的海外好物里校验是否存在
    '''
    def test14(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobei("title1", "decription1", "1", "1").goto_checkGoodthingsoverseas()

    '''
    创建商品标签为家乡好物的宝贝并在推荐列表的家乡好物里校验是否存在
    '''
    def test15(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobeiForHometowngoodies("title1", "decription1", "1", "1").goto_checkHometowngoodies()
    '''
    发布宝贝，点赞宝贝并删除宝贝，在赞过里清空失效宝贝
    '''
    def test16(self):
        assert App().start().goto_privatedOrder().goto_publishBaobei().publishBaobei("title", "description", "1", "1").goto_baobeiDetail().dianzan().goto_deleteBaobei().deleteBaobei().goto_privatedOrder().goto_mine().goto_swipeup_mine().goto_zanguo().goto_baobei().clearinvalidBaobei()