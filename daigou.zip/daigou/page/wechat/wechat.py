from page.basepage.basepage import BasePage



class Wechat(BasePage):
    def cancelPayment(self):
        self.steps("../../page/wechat/wechat.yaml", "cancelPayment")
        from page.orderDetail.orderDetail import OrderDetail
        return OrderDetail(self.driver)
    def cancelPaymentAndBacktoTopayment(self):
        self.steps("../../page/wechat/wechat.yaml", "cancelPaymentAndBacktoTopayment")
        from page.topayment.topayment import Topayment
        return Topayment(self.driver)
    def cancelPaymentAndBacktoGoodsOrder(self):
        self.steps("../../page/wechat/wechat.yaml", "cancelPaymentAndBacktoGoodsOrder")
        from page.goodsOrder.goodsOrder import GoodsOrder
        return GoodsOrder(self.driver)
    def cancelPaymentAndBacktoMyOrderInPersonalCenter(self):
        self.steps("../../page/wechat/wechat.yaml", "cancelPaymentAndBacktoMyOrderInPersonalCenter")
        from page.myOrderInPersonalCenter.myOrderInPersonalCenter import MyOrderInPersonalCenter
        return MyOrderInPersonalCenter(self.driver)
    def backtoOrderDetailInPersonalCt(self):
        self.steps("../../page/wechat/wechat.yaml", "backtoOrderDetailInPersonalCt")
        from page.orderDetailInPersonCt.orderDetailInPersonCt import OrderDetailInPersonCt
        return OrderDetailInPersonCt(self.driver)
    def switchtoNativeappInWechat(self):
        self.steps("../../page/wechat/wechat.yaml", "backtoNativeappInWechat")
        return self
    def getContexts(self):
        print(self.driver.contexts)
        print(self.driver.window_handles)
        return self








