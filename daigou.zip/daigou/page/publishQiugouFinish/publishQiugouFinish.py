from page.basepage.basepage import BasePage



class PublishQiugouFinish(BasePage):
    def goto_swipedown_publishQiugouFinish(self):
        self.steps("../../page/publishQiugouFinish/publishQiugouFinish.yaml", "goto_swipedown_publishQiugouFinish")
        return self
    def backtoQiugou(self):
        self.steps("../../page/publishQiugouFinish/publishQiugouFinish.yaml", "backtoQiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)
    def viewxuqiu(self):
        self.steps("../../page/publishQiugouFinish/publishQiugouFinish.yaml", "viewxuqiu")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)