from page.baobei.baobeiDetail import BaobeiDetail
from page.baobei.editBaobei import EditBaobei
from page.baobei.publishBaobei import PublishBaobei
from page.basepage.basepage import BasePage
from page.mine.mine import Mine

from page.shoppingcart.shoppingcart import Shoppingcart
'''
 action = TouchAction(self.driver)
 action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()
 相当于
 self.driver.swipe(x1,y_start,x1,y_end, duration = 5000)
'''

class PrivatedOrder(BasePage):
    # 去发布宝贝
    def goto_publishBaobei(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_publishBaobei")
        return PublishBaobei(self.driver)
    # 打开宝贝详情页面
    def goto_baobeiDetail(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_baobeiDetail")
        return BaobeiDetail(self.driver)
    # 去编辑宝贝
    def goto_editBaobei(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_editBaobei")
        return EditBaobei(self.driver)
    #打开我的页面
    def goto_mine(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_mine")
        return Mine(self.driver)

    # 上滑宝贝列表页面
    def goto_switchupBaobeiList(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_switchupBaobeiList")
        return self

    # 打开购物车页面
    def goto_shoppingcart(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_shoppingcart")
        return Shoppingcart(self.driver)
    # 打开搜索页面
    def goto_searchBaobei(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_searchBaobei")
        from page.searchBaobei.searchBaobei import SearchBaobei
        return SearchBaobei(self.driver)
    def goto_checkGoodthingsoverseas(self):
        baobeiTitileInPublishBaobei = self._params["title"]
        baobeiTitleBaibeiList = self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_checkGoodthingsoverseas")
        return baobeiTitileInPublishBaobei == baobeiTitleBaibeiList
    def goto_checkHometowngoodies(self):
        baobeiTitileInPublishBaobei = self._params["title"]
        baobeiTitleBaibeiList = self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_hometowngoodies")
        return baobeiTitileInPublishBaobei == baobeiTitleBaibeiList

    # 打开求购页面
    def goto_qiugou(self):
        self.steps("../../page/privatedOrder/privatedOrder.yaml", "goto_qiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)


    #
    #
    # # 取消搜索宝贝
    # def goto_cancelSearchBaobei(self, keyword):
    #     self._params["keyword"] = keyword
    #     self.steps("privatedOrder.yaml", "goto_cancelSearchBaobei")
    #     return CancelSearchBaobei(self.driver)
    #
    #
    # # 删除宝贝历史搜素
    # def goto_deleteHistorySearchForBaobei(self, keyword):
    #     self._params["keyword"] = keyword
    #     self.steps("privatedOrder.yaml", "goto_deleteHistorySearchForBaobei")
    #     return DeleteHistorySearchForBaobei(self.driver)
    #
    # # def gotoDaiquan(self):
    # #     self.driver.find_element(MobileBy.XPATH, "//*[@text='待圈']").click()
    # #     element1 = self.driver.find_element(MobileBy.ID, "com.daigou.purchaserapp:id/tvMyCustomize").text
    # #     return Daiquan(self.driver)
    #
    # # 收藏一个求购，并在我的中检验是否正确
    # def collectAQiugouAndCheckMycollectInDaiquan(self):
    #     '''
    #     收藏求购前，先检验我的收藏列表是否有求购，如果有，先删除，否则，再进行收藏
    #     :return:
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='待圈']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     while True:
    #         try:
    #             locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #             self.set_webdriverWait_untilnot(locator,1)
    #             # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #         except Exception as e:
    #             print(e)
    #             self.back()
    #             break
    #     sleep(2)
    #     '''
    #     删除我的收藏里的求购后，再将求购加入收藏
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='求购']")
    #     element1 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[0]
    #     text1 = element1.text
    #     element1.click()
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #     self.back()
    #     self.getClick(MobileBy.XPATH, "//*[@text='待圈']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     text2 = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #     return text1 == text2
    # # 收藏两个求购，并在待购圈中检验是否正确
    # def collectTwoQiugouAndCheckMycollectInDaiquan(self):
    #     '''
    #             收藏求购前，先检验我的收藏列表是否有求购，如果有，先删除，否则，再进行收藏
    #             :return:
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='待圈']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     while True:
    #         try:
    #             locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #             self.set_webdriverWait_untilnot(locator,1)
    #             # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #         except Exception as e:
    #             print(e)
    #             self.back()
    #             break
    #     sleep(2)
    #     '''
    #     将求购加入收藏
    #     '''
    #     # 切换到求购页面
    #     self.getClick(MobileBy.XPATH, "//*[@text='求购']")
    #     # 页面上滑，显示多个求购
    #     sleep(3)
    #     action = TouchAction(self.driver)
    #     window_size = self.driver.get_window_size()
    #     width = window_size["width"]
    #     height = window_size["height"]
    #     x = width * 1 / 2
    #     y_start = height * 7 / 8
    #     y_end = height * 5 / 8
    #     action.press(x=x, y=y_start).wait(200).move_to(x=x, y=y_end).release().perform()
    #     # 加入一个求购
    #     element1 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[0]
    #     text1 = element1.text
    #     element1.click()
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #     self.back()
    #     # 加入第二个求购
    #     action.press(x=x, y=y_start).wait(200).move_to(x=x, y=y_end).release().perform()
    #     element2 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[1]
    #     text2 = element2.text
    #     element2.click()
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #     self.back()
    #     self.getClick(MobileBy.XPATH, "//*[@text='待圈']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     secondQiugouText = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")[0].text
    #     firstQiugouText = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")[1].text
    #     return text1 == firstQiugouText and text2 == secondQiugouText
    # # 取消收藏一个求购并在待圈中校验是否正确
    # def cancelCollectAQiugouAndCheckMycollectInDaiquan(self):
    #     if(self.collectAQiugouAndCheckMycollectInDaiquan()):
    #         qiugouList = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #         if(len(qiugouList) == 1):
    #             qiugouList[0].click()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #             return self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #         elif(len(qiugouList) >= 2):
    #             while True:
    #                 try:
    #                     locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                     self.set_webdriverWait_untilnot(locator,1)
    #                     # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #                     sleep(5)
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #                     self.back()
    #                     self.back()
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #                 except Exception as e:
    #                     print("取消收藏求购成功")
    #                     break
    #     return True
    #
    # # 取消收藏两个求购并在待圈中校验是否正确
    # def cancelCollectTwoQiugouAndCheckMycollectInDaiquan(self):
    #     if(self.collectTwoQiugouAndCheckMycollectInDaiquan()):
    #         qiugouList = self.driver.find_elements(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #         if(len(qiugouList) == 1):
    #             qiugouList[0].click()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #             return self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #         elif(len(qiugouList) >= 2):
    #             while True:
    #                 try:
    #                     locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                     self.set_webdriverWait_untilnot(locator,1)
    #                     # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #                     sleep(5)
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/ivCollection")
    #                     self.back()
    #                     self.back()
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #                 except Exception as e:
    #                     print("取消收藏求购成功")
    #                     break
    #     return True
    #
    #
    # # 收藏一个宝贝，并在我的中检验是否正确
    # def collectABaobeiAndCheckMycollectInDaiquan(self):
    #     '''
    #     收藏前，先检验我的收藏列表是否有宝贝，如果有，先删除，否则，再进行收藏
    #     :return:
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='我的']")
    #     self.getClick(MobileBy.XPATH, "//*[@text='赞过']")
    #     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #     while True:
    #         try:
    #             locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #             self.set_webdriverWait_untilnot(locator, 1)
    #             # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #             self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #         except Exception as e:
    #             print(e)
    #             self.back()
    #             break
    #     sleep(2)
    #     '''
    #     将宝贝加入收藏
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='推荐']")
    #     element1 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[0]
    #     print(element1)
    #     text1 = element1.text
    #     element1.click()
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #     self.back()
    #     self.getClick(MobileBy.XPATH, "//*[@text='我的']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #     text2 = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #     return text1 == text2
    #
    # # 收藏两个宝贝，并在我的中检验是否正确
    # def collectTwoBaobeiAndCheckMycollectInDaiquan(self):
    #     '''
    #     收藏宝贝前，先检验我的收藏列表是否有求购，如果有，先删除，否则，再进行收藏
    #     :return:
    #     '''
    #     self.getClick(MobileBy.XPATH, "//*[@text='我的']")
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #     while True:
    #         try:
    #             locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #             self.set_webdriverWait_untilnot(locator, 1)
    #             # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.XPATH, "//*[@text='赞过']")
    #             self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #         except Exception as e:
    #             print(e)
    #             self.back()
    #             break
    #     '''
    #     将宝贝加入收藏
    #     '''
    #     # 切换到推荐页面
    #     self.getClick(MobileBy.XPATH, "//*[@text='推荐']")
    #     # 页面上滑，显示多个宝贝
    #     # sleep(3)
    #     self.getClick(MobileBy.XPATH, "//*[@text='家乡好物']")
    #     action = TouchAction(self.driver)
    #     window_size = self.driver.get_window_size()
    #     width = window_size["width"]
    #     height = window_size["height"]
    #     x = width * 1 / 2
    #     y_start = height * 7 / 8
    #     y_end = height * 5 / 8
    #     action.press(x=x, y=y_start).wait(200).move_to(x=x, y=y_end).release().perform()
    #     #在列表中找到一个宝贝
    #     element1 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[0]
    #     # 获取到这个宝贝的text
    #     text1 = element1.text
    #     # 打印宝贝1文本
    #     print(text1)
    #     # 打开宝贝详情
    #     element1.click()
    #     # 点赞宝贝
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #     self.back()
    #     # 滑动页面
    #     action.press(x=x, y=y_start).wait(200).move_to(x=x, y=y_end).release().perform()
    #     # 找到另一个宝贝
    #     element2 = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")[1]
    #     # 获取宝贝属性
    #     text2 = element2.text
    #     #打印宝贝2文本
    #     print(text2)
    #     # 打开宝贝详情
    #     element2.click()
    #     # 点赞宝贝
    #     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #     self.back()
    #     # 打开我的页面
    #     self.getClick(MobileBy.XPATH, "//*[@text='我的']")
    #     self.getClick(MobileBy.XPATH, "//*[@text='赞过']")
    #     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #     elementList = self.finds(MobileBy.XPATH, "//*[@resource-id='com.daigou.purchaserapp:id/rvNormal']//*[@resource-id='com.daigou.purchaserapp:id/tvProductTitle']")
    #     fistBaobeiText = elementList[0].text
    #     secondBaobeiText = elementList[1].text
    #     print(fistBaobeiText)
    #     print(secondBaobeiText)
    #     return text1 == secondBaobeiText and text2 == fistBaobeiText
    #
    # # 取消收藏一个宝贝
    # def cancelCollectABaobeiAndCheckMycollectInDaiquan(self):
    #     if(self.collectABaobeiAndCheckMycollectInDaiquan()):
    #         qiugouList = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #         if(len(qiugouList) == 1):
    #             qiugouList[0].click()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #             sleep(3)
    #             self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #             return self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #         elif(len(qiugouList) >= 2):
    #             while True:
    #                 try:
    #                     locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                     self.set_webdriverWait_untilnot(locator, 1)
    #                     # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #                     self.back()
    #                     self.back()
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #                     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #                 except Exception as e:
    #                     print("取消收藏求购成功")
    #                     break
    #     return True
    #
    # # 取消收藏两个宝贝
    # def cancelCollectTwoBaobeiAndCheckMycollectInDaiquan(self):
    #     if (self.collectTwoBaobeiAndCheckMycollectInDaiquan()):
    #         qiugouList = self.finds(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #         if (len(qiugouList) == 1):
    #             qiugouList[0].click()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #             self.back()
    #             self.back()
    #             self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #             sleep(3)
    #             self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #             return self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #         elif (len(qiugouList) >= 2):
    #             while True:
    #                 try:
    #                     locator = (MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                     self.set_webdriverWait_untilnot(locator, 1)
    #                     # WebDriverWait(self.driver, 1, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/tvCollection")
    #                     self.back()
    #                     self.back()
    #                     self.getClick(MobileBy.ID, "com.daigou.purchaserapp:id/iViService")
    #                     self.getClick(MobileBy.XPATH, "//*[@text='宝贝']")
    #                 except Exception as e:
    #                     print("取消收藏求购成功")
    #                     break
    #     return True
    #
    #
    # # 在我的收藏里删除一个求购
    # def deleteAQiugouInMyCollect(self):
    #     if(self.collectAQiugouAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         while True:
    #             try:
    #                 locator = (MobileBy.ID, "com.daigou.purchaserapp:id/cbDelete")
    #                 self.set_webdriverWait_unit(locator, 1)
    #                 # WebDriverWait(self.driver, 1, 0.5).until(expected_conditions.visibility_of_element_located(locator))
    #                 self.getClick(*locator)
    #                 self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #                 self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #                 element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                 element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #                 return element_zanwushoucang and "管理" in element_manage_text
    #             except Exception as e:
    #                 print(e)
    #                 break
    #
    # # 在我的收藏里删除所有求购
    # def delateAllQiugouInMyCollect(self):
    #     if(self.collectTwoQiugouAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         while True:
    #             try:
    #                 locator = (MobileBy.ID, "com.daigou.purchaserapp:id/cbDelete")
    #                 self.set_webdriverWait_unit(locator, 1)
    #                 # WebDriverWait(self.driver, 1, 0.5).until(expected_conditions.visibility_of_element_located(locator))
    #                 self.getClick(*locator)
    #                 self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #                 sleep(1)
    #             except Exception as e:
    #                 print(e)
    #                 break
    #     self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #     element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #     element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #     return element_zanwushoucang and "管理" in element_manage_text
    #
    # # 在我的收藏里删除一个宝贝
    # def deleteABaobeiInMyCollect(self):
    #     if (self.collectABaobeiAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         while True:
    #             try:
    #                 locator = (MobileBy.ID, "com.daigou.purchaserapp:id/cbDelete")
    #                 self.set_webdriverWait_unit(locator, 1)
    #                 # WebDriverWait(self.driver, 1, 0.5).until(expected_conditions.visibility_of_element_located(locator))
    #                 self.getClick(*locator)
    #                 self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #                 self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #                 element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #                 element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #                 return element_zanwushoucang and "管理" in element_manage_text
    #             except Exception as e:
    #                 print(e)
    #                 break
    #
    # # 在我的收藏里删除两个宝贝
    # def deleteMultipleBaobeiInMyCollect(self):
    #     if (self.collectTwoBaobeiAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         while True:
    #             try:
    #                 locator = (MobileBy.ID, "com.daigou.purchaserapp:id/cbDelete")
    #                 self.set_webdriverWait_unit(locator, 0.5)
    #                 # WebDriverWait(self.driver, 1, 0.5).until(expected_conditions.visibility_of_element_located(locator))
    #                 self.getClick(*locator)
    #                 self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #             except Exception as e:
    #                 print(e)
    #                 break
    #     self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #     element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #     element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #     return element_zanwushoucang and "管理" in element_manage_text
    #
    # # 在我的收藏里全选宝贝并删除
    # def selectAllBaobeiAndDeleteInMyCollect(self):
    #     if (self.collectTwoBaobeiAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='全选']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #     element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #     element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #     return element_zanwushoucang and "管理" in element_manage_text
    #
    # # 在我的收藏里全选求购并删除
    # def selectAllQiugouAndDeleteInMyCollect(self):
    #     if (self.collectTwoQiugouAndCheckMycollectInDaiquan()):
    #         self.getClick(MobileBy.XPATH, "//*[@text='管理']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='全选']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='删除']")
    #         self.getClick(MobileBy.XPATH, "//*[@text='完成']")
    #     element_zanwushoucang = self.find(MobileBy.XPATH, "//*[@text='暂无收藏~']")
    #     element_manage_text = self.getText(MobileBy.ID, "com.daigou.purchaserapp:id/tv_edit")
    #     return element_zanwushoucang and "管理" in element_manage_text

