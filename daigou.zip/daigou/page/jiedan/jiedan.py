from page.basepage.basepage import BasePage



class Jiedan(BasePage):
    def jiedan(self, baobeiDescription, price):
        self._params["baobeiDescription"] = baobeiDescription
        self._params["price"] = price
        if(self.steps("../../page/jiedan/jiedan.yaml", "jiedan")):
            from page.qiugouDetail.qiugouDetail import QiugouDetail
            return QiugouDetail(self.driver)
