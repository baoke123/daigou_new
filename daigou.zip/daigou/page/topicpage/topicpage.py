from page.basepage.basepage import BasePage


class Topicpage(BasePage):
    def getTopiclink(self):
        topiclinkInTopicpage = self.steps("../../page/topicpage/topicpage.yaml", "getTopiclink")
        self._asserts["topiclinkInTopicpage"] = str(topiclinkInTopicpage)
        return self
    def checkTopiclink(self):
        return self._asserts["topiclinkInQiugouDetail"] == self._asserts["topiclinkInTopicpage"]