from page.basepage.basepage import BasePage



class Shoppingbag(BasePage):
    def goto_privatedShoppingcart(self):
        return self.steps("../../page/shoppingbag/shoppingbag.yaml", "goto_privatedShoppingcart")
    def deleteGoods(self):
        if(self.steps("../../page/shoppingbag/shoppingbag.yaml", "deleteGoods")):
            from page.market.market import Market
            return Market(self.driver)
    def settle(self):
        self.steps("../../page/shoppingbag/shoppingbag.yaml", "settle")
        from page.confirmOrder.confirmOrder import ConfirmOrder
        return ConfirmOrder(self.driver)




