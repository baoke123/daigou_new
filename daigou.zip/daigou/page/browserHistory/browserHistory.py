from appium.webdriver.common.mobileby import MobileBy
from page.basepage.basepage import BasePage
class BrowserHistory(BasePage):
    def deleteBrowserHistroy(self):
        if(self.steps("../../page/browserHistory/browserHistory.yaml", "deleteBrowserHistroy")):
            return self
    def goto_backtoPersonalCenter(self):
        self.steps("../../page/browserHistory/browserHistory.yaml", "goto_backtoPersonalCenter")
        from page.personalCenter.personalCenter import PersonalCenter
        return PersonalCenter(self.driver)
    def checkAndClearRecords(self):
        locator_browserHistory = (MobileBy.ID, "com.daigou.purchaserapp:id/tvName")
        browserHistoryList = self.finds(locator_browserHistory)
        if(len(browserHistoryList) > 0):
            self.steps("../../page/browserHistory/browserHistory.yaml", "clearrecords")
            return self
        else:
            return self

    def goto_goodsDetail(self):
        self.steps("../../page/browserHistory/browserHistory.yaml", "goto_goodsDetail")
        from page.goodsDetail.goodsDetail import GoodsDetail
        return GoodsDetail(self.driver)

