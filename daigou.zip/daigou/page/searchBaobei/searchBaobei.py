
from page.basepage.basepage import BasePage



class SearchBaobei(BasePage):
    def searchBaobei(self, keyword):
        self._params["keyword"] = keyword
        self.steps("../../page/searchBaobei/searchBaobei.yaml", "searchBaobei")
        return self
    def goto_baobeiDetail(self):
        self.steps("../../page/searchBaobei/searchBaobei.yaml", "goto_baobeiDetail")
        from page.baobei.baobeiDetail import BaobeiDetail
        return BaobeiDetail(self.driver)
    def cancelSearchBaobei(self):
        self.steps("../../page/searchBaobei/searchBaobei.yaml", "cancelSearchBaobei")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def deleteHistorySearchForBaobei(self):
        return self.steps("../../page/searchBaobei/searchBaobei.yaml", "deleteHistorySearchForBaobei")

