from appium.webdriver.common.mobileby import MobileBy
from page.basepage.basepage import BasePage
class ConfirmOrder(BasePage):
    def checkAddressAndAdd(self, name, phoneNumber, detailAddress):
        self._params["name"] = name
        self._params["phoneNumber"] = phoneNumber
        self._params["detailAddress"] = detailAddress
        locator_address = (MobileBy.ID, "com.daigou.purchaserapp:id/tvAddress")
        addressList = self.finds(locator_address)
        if (len(addressList) > 0):
            return self
        else:
            self.steps("../../page/confirmOrder/confirmOrder.yaml", "addAddress")
            return self
    def payimmediately(self):
        self.steps("../../page/confirmOrder/confirmOrder.yaml", "payimmediately")
        from page.wechat.wechat import Wechat
        return Wechat(self.driver)