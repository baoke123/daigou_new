from page.basepage.basepage import BasePage


class UndercarriageBaobeiList(BasePage):
    def deleteBaobei(self):
        return self.steps("../../page/undercarriageBaobeiList/undercarriageBaobeiList.yaml", "deleteBaobei")
    def republishBaobei(self, title, description, price, num):
        self._params["title"] = title
        self._params["description"] = description
        self._params["price"] = price
        self._params["num"] = num
        return self.steps("../../page/undercarriageBaobeiList/undercarriageBaobeiList.yaml", "republishBaobei")

