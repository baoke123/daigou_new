from time import sleep
from appium.webdriver.common.mobileby import MobileBy
from appium.webdriver.common.touch_action import TouchAction
from page.basepage.basepage import BasePage
class MyCollect(BasePage):
    def deleteCollectedGoods(self):
        return self.steps("../../page/mycollect/mycollect.yaml", "deleteCollectedGoods")

    def checkAndDeleteCollectedGoods(self):
        locator_edit = (MobileBy.XPATH, "//*[@text='编辑']")
        elementlist_edit = self.finds(locator_edit)
        if(len(elementlist_edit) > 0):
            self.getClick(locator_edit)
            sleep(2)
            action = TouchAction(self.driver)
            action.tap(x=45, y=1226).release().perform()
            self.getClick((MobileBy.XPATH, "//*[@text='删除']"))
        return self

    def goto_quguangguang(self):
        self.steps("../../page/mycollect/mycollect.yaml", "goto_quguangguang")
        from page.market.market import Market
        return Market(self.driver)



