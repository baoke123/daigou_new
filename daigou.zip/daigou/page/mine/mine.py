from page.basepage.basepage import BasePage



class Mine(BasePage):
    def goto_jiedanInMine(self):
        self.steps("../../page/mine/mine.yaml", "goto_jiedanInMine")
        from page.jiedanInMine.jiedanInMine import JiedanInMine
        return JiedanInMine(self.driver)

    def goto_zanguo(self):
        self.steps("../../page/mine/mine.yaml", "goto_zanguo")
        from page.zanguo.zanguo import Zanguo
        return Zanguo(self.driver)
    def goto_goodsOrderList(self):
        self.steps("../../page/mine/mine.yaml", "goto_goodsOrderList")
        from page.goodsOrderList.goodsOrderList import GoodsOrderList
        return GoodsOrderList(self.driver)
    def goto_privatedOrder(self):
        self.steps("../../page/mine/mine.yaml", "goto_privatedOrder")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def goto_backtoQiugou(self):
        self.steps("../../page/mine/mine.yaml", "goto_backtoQiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)
    def goto_swipeup_mine(self):
        self.steps("../../page/mine/mine.yaml", "goto_swipeup_mine")
        return self
    def goto_myorder(self):
        self.steps("../../page/mine/mine.yaml", "goto_myorder")
        from page.myOrder.myOrder import MyOrder
        return MyOrder(self.driver)

