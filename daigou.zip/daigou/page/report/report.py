from page.basepage.basepage import BasePage


class Report(BasePage):
    def report(self, description):
        self._params["description"] = description
        return self.steps("../../page/report/report.yaml", "report")