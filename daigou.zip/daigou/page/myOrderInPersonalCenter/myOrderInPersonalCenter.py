from time import sleep

from appium.webdriver.common.mobileby import MobileBy

from page.basepage.basepage import BasePage
from logzero import logger

class MyOrderInPersonalCenter(BasePage):
    def cancelOrder(self):
        if (self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "cancelOrder")):
            return self

    def deleteOrder(self):
        return self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "deleteOrder")

    # def payimmediately(self):
    #     self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "payimmediately")
    #     from page.wechat.wechat import Wechat
    #     return Wechat(self.driver)

    # def payimmediatelyInMyOrder(self):
    #     self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "payimmediatelyInMyOrder")
    #     from page.wechat.wechat import Wechat
    #     return Wechat(self.driver)

    def goto_OrderDetailInPersonCt(self):
        self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "goto_OrderDetailInPersonCt")
        from page.orderDetailInPersonCt.orderDetailInPersonCt import OrderDetailInPersonCt
        return OrderDetailInPersonCt(self.driver)

    def payimmediatelyInMyOrder(self):
        self.steps("../../page/myOrderInPersonalCenter/myOrderInPersonalCenter.yaml", "payimmediatelyInMyOrder")
        from page.wechat.wechat import Wechat
        return Wechat(self.driver)
