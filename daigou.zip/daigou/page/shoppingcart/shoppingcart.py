from page.basepage.basepage import BasePage
from page.confirmOrder.confirmOrder import ConfirmOrder
class Shoppingcart(BasePage):
    def settle(self):
        self.steps("../../page/shoppingcart/shoppingcart.yaml", "settle")
        return ConfirmOrder(self.driver)
    def goto_shoppingcartDownSwipe(self):
        self.steps("../../page/shoppingcart/shoppingcart.yaml", "goto_shoppingcartDownSwipe")
        return self
    def clearShoppingcart(self):
        self.steps("../../page/shoppingcart/shoppingcart.yaml", "clearShoppingcart")
        return self
    def clickquguangguang(self):
        self.steps("../../page/shoppingcart/shoppingcart.yaml", "clickquguangguang")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def settleBaobeiSearched(self):
        self.steps("../../page/shoppingcart/shoppingcart.yaml", "settleBaobeiSearched")
        return ConfirmOrder(self.driver)

