from page.basepage.basepage import BasePage


class GoodsOrder(BasePage):
    def checkGoodsOrder(self):
        return self.steps("../../page/goodsOrder/goodsOrder.yaml", "checkGoodsOrder")