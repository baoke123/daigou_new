from page.basepage.basepage import BasePage
class Topayment(BasePage):
    def payimmediately(self):
        self.steps("../../page/topayment/topayment.yaml", "payimmediately")
        from page.wechat.wechat import Wechat
        return Wechat(self.driver)
    def cancelOrder(self):
        if(self.steps("../../page/topayment/topayment.yaml", "cancelOrder")):
            return self
    def goto_checkAndClearAllOrders(self):
        self.steps("../../page/topayment/topayment.yaml", "goto_checkAndClearAllOrders")
        from page.mine.mine import Mine
        return Mine(self.driver)
    def goto_goodsOrderList(self):
        self.steps("../../page/topayment/topayment.yaml", "goto_goodsOrderList")
        from page.goodsOrderList.goodsOrderList import GoodsOrderList
        return GoodsOrderList(self.driver)