from page.basepage.basepage import BasePage
from page.browserHistory.browserHistory import BrowserHistory



class PersonalCenter(BasePage):
    def goto_browserHistory(self):
        self.steps("../../page/personalCenter/personalCenter.yaml", "goto_browserHistory")
        from page.browserHistory.browserHistory import BrowserHistory
        return BrowserHistory(self.driver)
    def goto_collectGoods(self):
        self.steps("../../page/personalCenter/personalCenter.yaml", "goto_collectGoods")
        from page.mycollect.mycollect import MyCollect
        return MyCollect(self.driver)
    def goto_market(self):
        self.steps("../../page/personalCenter/personalCenter.yaml", "goto_market")
        from page.market.market import Market
        return Market(self.driver)
