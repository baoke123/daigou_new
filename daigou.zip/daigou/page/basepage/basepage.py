import json
from time import sleep

import yaml
from appium.webdriver.common.mobileby import MobileBy
from appium.webdriver.common.touch_action import TouchAction
from appium.webdriver.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait


class BasePage:
    import sys
    sys.setrecursionlimit(3000)
    _params = {}
    _asserts = {}

    def __init__(self, driver: WebDriver = None):
        self.driver = driver

    def set_webdriverWait_unit(self, locator, second):
        WebDriverWait(self.driver, second, 0.5).until(expected_conditions.visibility_of_element_located(locator))

    def set_webdriverWait_untilnot(self, locator, second):
        WebDriverWait(self.driver, second, 0.5).until_not(expected_conditions.visibility_of_element_located(locator))

    def set_implicitly_wait(self, second):
        self.driver.implicitly_wait(second)

    def getClick(self, by, locator=None):
        if locator is None:
            self.driver.find_element(*by).click()
        else:
            self.driver.find_element(by, locator).click()

    def getClicklatest(self, by, locator=None):
        if locator is None:
            self.driver.find_elements(*by)[-1].click()
        else:
            self.driver.find_elements(by, locator)[-1].click()

    def find(self, by, locator=None):
        if locator is None:
            element = self.driver.find_element(*by)
        else:
            element = self.driver.find_element(by, locator)
        return element

    def switch_context(self):
        contexts = self.driver.contexts
        current_context = self.driver.current_context
        for context in contexts:
            if current_context not in context:
                self.driver.switch_to.context(context)
    def switch_defaultcontext(self):
        self.driver.switch_to.default_content()

    def finds(self, by, locator=None):
        if locator is None:
            elements = self.driver.find_elements(*by)
        else:
            elements = self.driver.find_elements(by, locator)
        return elements

    def getText(self, by, locator=None):
        if locator is None:
            text = self.find(*by).text
        else:
            text = self.find(by, locator).text
        return text

    def steps(self, path, name):
        with open(path, encoding="utf-8") as f:
            steps = yaml.safe_load(f)[name]
        raw = json.dumps(steps)
        for key, value in self._params.items():
            raw = raw.replace('${' + key + '}', value)
        steps = json.loads(raw)
        for step in steps:
            if "action" in step.keys():
                action = step["action"]
                if "click" == action:
                    self.find(step["by"], step["locator"]).click()
                if "clicklatest" == action:
                    self.finds(step["by"], step["locator"])[-1].click()
                if "clear" == action:
                    self.find(step["by"], step["locator"]).clear()
                if "send" == action:
                    self.find(step["by"], step["locator"]).send_keys(step["value"])
                if "len > 0" == action:
                    eles = self.finds(step["by"], step["locator"])
                    return len(eles) > 0
                if "len < 0" == action:
                    eles = self.finds(step["by"], step["locator"])
                    return len(eles) < 1
                if "text" == action:
                    eles = self.getText(step["by"], step["locator"])
                    return eles
            if "back" in step.keys():
                self.back()
            if "back_wait" in step.keys():
                self.back_wait()
            if "sleep" in step.keys():
                sleep(5)
            if "press_publishQiugou" in step.keys():
                self.press_publishQiugou()
            if "press_shoppingBag" in step.keys():
                self.press_shoppingBag()
            if "press" in step.keys():
                self.press()
            if "backtoSendGoodsPlace" in step.keys():
                self.backtoSendGoodsPlace()
            if "implicitly_wait" in step.keys():
                self.set_implicitly_wait(5)
            if "press_youxiajiao" in step.keys():
                self.press_youxiajiao()
            if "press_my" in step.keys():
                self.press_my()
            if "press_confirmOrder" in step.keys():
                self.press_confirmOrder()
            if "press_goodsDetail" in step.keys():
                self.press_goodsDetail()
            if "total" in step.keys():
                return self.getTotal(step["by_price"], step["locator_price"], step["by_num"], step["locator_num"], step["by_total"], step["locator_total"])
            if "findBaobeiAndGotoEdit" in step.keys():
                self.findBaobeiAndGotoEdit()
            if "findBaobeiAndGotoUndercarriage" in step.keys():
                self.findBaobeiAndGotoUndercarriage()
            if "findBaobeiAndGotoDelete" in step.keys():
                self.findBaobeiAndGotoDelete()
            if "pay_immediately" in step.keys():
                self.pay_immediately()
            if "gotozanguo" in step.keys():
                self.gotozanguo()
            if "gotoswitchupBaobeiList" in step.keys():
                self.gotoswitchupBaobeiList()
            if "press_topayment" in step.keys():
                self.press_topayment()
            if "checkAndClearAllOrders" in step.keys():
                self.checkAndClearAllOrders()
            if "shoppingcartDownSwipe" in step.keys():
                self.shoppingcartDownSwipe()
            if "swipedown_publishQiugouFinish" in step.keys():
                self.swipedown_publishQiugouFinish()
            if "swipedown_qiugouDetail" in step.keys():
                self.swipedown_qiugouDetail()
            if "swipeup_qiugouDetail" in step.keys():
                self.swipeup_qiugouDetail()
            if "swipeup_mine" in step.keys():
                self.swipeup_mine()
            if "swipeup_qiugou" in step.keys():
                self.swipeup_qiugou()
            if "swipedown_myorder" in step.keys():
                self.swipedown_myorder()
            if "swipeup_market" in step.keys():
                self.swipeup_market()
            if "switch_context" in step.keys():
                self.switch_context()
            if "switch_defaultcontext" in step.keys():
                self.switch_defaultcontext()
            if "swipeup_goodsDetail" in step.keys():
                self.swipeup_goodsDetail()
    def swipeup_goodsDetail(self):
        sleep(3)
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 4 / 5 * y
        y_end = 3 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(500).move_to(x=x1, y=y_end).release().perform()

    def swipeup_market(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 2 / 3 * y
        y_end = 1 / 3 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(500).move_to(x=x1, y=y_end).release().perform()

    def swipedown_myorder(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 1 / 3 * y
        y_end = 2 / 3 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(500).move_to(x=x1, y=y_end).release().perform()

    def swipeup_qiugou(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 3 / 5 * y
        y_end = 1 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def swipeup_mine(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 3 / 5 * y
        y_end = 2 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def swipeup_qiugouDetail(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 3 / 5 * y
        y_end = 2 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def checkViewnum(self):
        locator_viewNum = (MobileBy.ID, "com.daigou.purchaserapp:id/tvViewCount")
        viewnumText1 = self.getText(locator_viewNum)
        self.back()
        locator_qiugou = (MobileBy.ID, "com.daigou.purchaserapp:id/tvGoodsName")
        self.getClick(locator_qiugou)
        viewnumText2 = self.getText(locator_viewNum)
        return int(viewnumText2) == int(viewnumText1) + 1

    def swipedown_qiugouDetail(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 2 / 5 * y
        y_end = 4 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def swipedown_publishQiugouFinish(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 2 / 5 * y
        y_end = 4 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def shoppingcartDownSwipe(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 2 / 5 * y
        y_end = 4 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def checkAndClearAllOrders(self):
        locator_order = (MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
        locator_cancelOrder = (MobileBy.XPATH, "//*[@text='取消订单']")
        locator_sure = (MobileBy.XPATH, "//*[@text='确定']")
        while True:
            try:
                self.set_webdriverWait_unit(locator_order, 2)
                self.getClick(locator_cancelOrder)
                self.getClick(locator_sure)
                self.back()
                break
            except Exception as e:
                self.back()
                break

    def press_topayment(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 2 / 5 * y
        y_end = 4 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def gotoswitchupBaobeiList(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 4 / 5 * y
        y_end = 2 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def gotozanguo(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 4 / 5 * y
        y_end = 2 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def getTotal(self, by_price, locator_price, by_num, locator_num, by_total, locator_total):
        total = self.getText(by_total, locator_total)
        price = float(self.getText(by_price, locator_price))
        num = int(self.getText(by_num, locator_num))
        print("合计：¥" + str(format(price * num, '.2f')))
        print(total)
        return total == "合计：¥" + str(format(price * num, '.2f'))

    def back(self):
        self.driver.back()

    def back_wait(self):
        while True:
            try:
                locator = (MobileBy.XPATH, "//*[@text='取消订单']")
                if (self.set_webdriverWait_untilnot(locator, 1)):
                    self.back()
            except Exception as e:
                print(e)
                break

    def press_publishQiugou(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 1 / 3 * y
        y_end = 2 / 3 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()
        # self.driver.swipe(x1,y_start,x1,y_end, duration = 5000)

    def press_my(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 1 / 5 * y
        y_end = 4 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def press_goodsDetail(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 4 / 5 * y
        y_end = 3 / 5 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def press_baobeiList(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 3 / 4 * y
        y_end = 1 / 2 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def clickText(self, by, locator=None):
        self.set_implicitly_wait(5000)
        if locator is None:
            element = self.find(*by)
        else:
            element = self.find(by, locator)
        text_num1 = element.text
        element.click()
        text_num2 = element.text
        element.click()
        text_num3 = element.text
        return int(text_num2) == int(text_num1) + 1 and int(text_num3) == int(text_num1)

    def findBaobeiAndGotoEdit(self):
        publishedbaobeiDescription = self._params["description"]
        # locator_publishedbaobeiElement = (MobileBy.XPATH, "//*[text()='" + publishedbaobeiDescription + "']")
        locator_publishedbaobeiElement = (
        MobileBy.XPATH, "//*[@text='螃蟹' and @resource-id='com.daigou.purchaserapp:id/tvGoodsName']")
        while True:
            try:
                element = self.set_webdriverWait_untilnot(locator_publishedbaobeiElement, 2)
                print(element)
                self.press_baobeiList()
            except Exception as e:
                print(e)
                publishedbaobei = self.find(locator_publishedbaobeiElement)
                if publishedbaobei:
                    publishedbaobei.click()
                    self.find((MobileBy.XPATH, "//*[@text='管理']")).click()
                    self.find((MobileBy.XPATH, "//*[@text='编辑']")).click()
                break

    def findBaobeiAndGotoUndercarriage(self):
        publishedbaobeiDescription = self._params["description"]
        # locator_publishedbaobeiElement = (MobileBy.XPATH, "//*[text()='" + publishedbaobeiDescription + "']")
        locator_publishedbaobeiElement = (
            MobileBy.XPATH, "//*[@text='螃蟹' and @resource-id='com.daigou.purchaserapp:id/tvGoodsName']")
        while True:
            try:
                element = self.set_webdriverWait_untilnot(locator_publishedbaobeiElement, 2)
                print(element)
                self.press_baobeiList()
            except Exception as e:
                print(e)
                publishedbaobei = self.find(locator_publishedbaobeiElement)
                if publishedbaobei:
                    publishedbaobei.click()
                    self.find((MobileBy.XPATH, "//*[@text='管理']")).click()
                break

    def findBaobeiAndGotoDelete(self):
        publishedbaobeiDescription = self._params["description"]
        # locator_publishedbaobeiElement = (MobileBy.XPATH, "//*[text()='" + publishedbaobeiDescription + "']")
        locator_publishedbaobeiElement = (
        MobileBy.XPATH, "//*[@text='螃蟹' and @resource-id='com.daigou.purchaserapp:id/tvGoodsName']")
        while True:
            try:
                element = self.set_webdriverWait_untilnot(locator_publishedbaobeiElement, 2)
                print(element)
                self.press_baobeiList()
            except Exception as e:
                print(e)
                publishedbaobei = self.find(locator_publishedbaobeiElement)
                if publishedbaobei:
                    publishedbaobei.click()
                    self.find((MobileBy.XPATH, "//*[@text='管理']")).click()
                break

    def press(self):
        window_size = self.driver.get_window_size()
        x = window_size["width"]
        y = window_size["height"]
        x1 = 0.5 * x
        y_start = 3 / 4 * y
        y_end = 1 / 4 * y
        action = TouchAction(self.driver)
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_end).release().perform()

    def press_youxiajiao(self):
        action = TouchAction(self.driver)
        window_size = self.driver.get_window_size()
        width = window_size["width"]
        height = window_size["height"]
        x1 = width * 7 / 8
        y1 = height * 14 / 15
        action.tap(x=x1, y=y1).release().perform()

    def press_shoppingBag(self):
        action = TouchAction(self.driver)
        window_size = self.driver.get_window_size()
        width = window_size["width"]
        height = window_size["height"]
        x1 = width * 1 / 2
        y_start = height * 1 / 3
        y_emd = height * 2 / 3
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_emd).release().perform()

    def press_confirmOrder(self):
        action = TouchAction(self.driver)
        window_size = self.driver.get_window_size()
        width = window_size["width"]
        height = window_size["height"]
        x1 = width * 1 / 2
        y_start = height * 3 / 5
        y_emd = height * 1 / 5
        action.press(x=x1, y=y_start).wait(200).move_to(x=x1, y=y_emd).release().perform()

    def backtoSendGoodsPlace(self):
        locator = (MobileBy.XPATH, "//*[@text='模式']")
        n = 0
        while True:
            try:
                self.set_webdriverWait_unit(locator, 1)
                self.back()
            except Exception as e:
                n += 1
                print(e)
                break
