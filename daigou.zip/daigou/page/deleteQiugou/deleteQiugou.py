from page.basepage.basepage import BasePage



class DeleteQiugou(BasePage):
    def deleteQiugou(self):
        if(self.steps("../../page/deleteQiugou/deleteQiugou.yaml", "deleteQiugou") > 0):
            from page.qiugou.qiugou import Qiugou
            return Qiugou(self.driver)


