from page.basepage.basepage import BasePage



class SearchGoods(BasePage):
    def searchGoods(self, searchGoods):
        self._params["searchGoods"] = searchGoods
        self.steps("../../page/searchGoods/searchGoods.yaml", "searchGoods")
        return self
    def cancelSearchGoods(self):
        self.steps("../../page/searchGoods/searchGoods.yaml", "cancelSearchGoods")
        from page.market.market import Market
        return Market(self.driver)
    def deleteHistorySearch(self):
        if(self.steps("../../page/searchGoods/searchGoods.yaml", "deleteHistorySearch")):
            return self




