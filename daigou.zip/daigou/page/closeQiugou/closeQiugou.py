from page.basepage.basepage import BasePage
class CloseQiugou(BasePage):
    def closeQiugou(self):
        return self.steps("../../page/closeQiugou/closeQiugou.yaml", "closeQiugou")
    def closeQiugouAndBacktoMyOrder(self):
        self.steps("../../page/closeQiugou/closeQiugou.yaml", "closeQiugouAndBacktoMyOrder")
        from page.myOrder.myOrder import MyOrder
        return MyOrder(self.driver)