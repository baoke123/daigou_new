from appium.webdriver.common.mobileby import MobileBy
from page.basepage.basepage import BasePage
class BaobeiDetail(BasePage):
    def checkBaobei(self):
        locator_manage = (MobileBy.XPATH, "//*[@text='管理']")
        element_manage = self.finds(locator_manage)
        if(len(element_manage) > 0):
            self.steps("../../page/baobei/baobeiDetail.yaml", "checkBaobei")
            return self
        else:
            return self
    def goto_editBaobei(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_editBaobei")
        from page.baobei.editBaobei import EditBaobei
        return EditBaobei(self.driver)
    def goto_undercarriageBaobei(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_undercarriageBaobei")
        from page.baobei.undercarriageBaobei import UndercarriageBaobei
        return UndercarriageBaobei(self.driver)
    def goto_deleteBaobei(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_deleteBaobei")
        from page.baobei.deleteBaobei import DeleteBaobei
        return DeleteBaobei(self.driver)
    def goto_republishBaobei(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_republishBaobei")
        from page.baobei.republishBaobei import RepublishBaobei
        return RepublishBaobei(self.driver)
    def goto_privatedOrder(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_privatedOrder")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def dianzan(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_dianzan")
        return self
    def addtoShoppingcart(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_addtoShoppingcart")
        return self
    def buyimmediately(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "buyimmediately")
        from page.confirmOrder.confirmOrder import ConfirmOrder
        return ConfirmOrder(self.driver)
    def goto_report(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_report")
        from page.report.report import Report
        return Report(self.driver)
    def savePicture(self):
        return self.steps("../../page/baobei/baobeiDetail.yaml", "savePicture")
    def goto_privatedOrderFromBaobeiDetailsearched(self):
        self.steps("../../page/baobei/baobeiDetail.yaml", "goto_privatedOrderFromBaobeiDetailsearched")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)