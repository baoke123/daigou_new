
from page.basepage.basepage import BasePage
class UndercarriageBaobei(BasePage):
    def undercarriageBaobei(self):
        self.steps("../../page/baobei/undercarriageBaobei.yaml", "undercarriageBaobei")
        from page.baobei.baobeiDetail import BaobeiDetail
        return BaobeiDetail(self.driver)
    def undercarriageBaobeiInBaobeiManage(self):
        self.steps("../../page/baobei/undercarriageBaobei.yaml", "undercarriageBaobeiInBaobeiManage")
        from page.baobeiManage.baobeiManage import BaobeiManage
        return BaobeiManage(self.driver)


