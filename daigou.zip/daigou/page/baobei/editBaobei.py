
from page.basepage.basepage import BasePage
class EditBaobei(BasePage):
    def editBaobei(self,title, description, price, num):
        self._params["title"] = title
        self._params["description"] = description
        self._params["price"] = price
        self._params["num"] = num
        self.steps("../../page/baobei/editBaobei.yaml", "editBaobei")
        from page.baobei.baobeiDetail import BaobeiDetail
        return BaobeiDetail(self.driver)
    def editBaobeiInBaobeiManage(self, title, description, price, num):
        self._params["title"] = title
        self._params["description"] = description
        self._params["price"] = price
        self._params["num"] = num
        self.steps("../../page/baobei/editBaobei.yaml", "editBaobeiInBaobeiManage")
        from page.baobeiManage.baobeiManage import BaobeiManage
        return BaobeiManage(self.driver)
