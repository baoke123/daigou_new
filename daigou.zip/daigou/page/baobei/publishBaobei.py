from page.basepage.basepage import BasePage



class PublishBaobei(BasePage):
    def publishBaobei(self, title, description, price, num):
        self._params["title"] = title
        self._params["description"] = description
        self._params["price"] = price
        self._params["num"] = num
        self.steps("../../page/baobei/publishBaobei.yaml", "publishBaobei")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def publishBaobeiForHometowngoodies(self, title, description, price, num):
        self._params["title"] = title
        self._params["description"] = description
        self._params["price"] = price
        self._params["num"] = num
        self.steps("../../page/baobei/publishBaobei.yaml", "publishBaobeiForHometowngoodies")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)

