from page.baobei.baobeiDetail import BaobeiDetail
from page.basepage.basepage import BasePage
class DeleteBaobei(BasePage):
    def deleteBaobei(self):
        self.steps("../../page/baobei/deleteBaobei.yaml", "deleteBaobei")
        return BaobeiDetail(self.driver)
    def deleteBaobeiInManage(self):
        return self.steps("../../page/baobei/deleteBaobei.yaml", "deleteBaobeiInManage")
