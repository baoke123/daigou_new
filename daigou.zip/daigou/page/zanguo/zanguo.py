
from page.basepage.basepage import BasePage



class Zanguo(BasePage):
    def goto_baobei(self):
        self.steps("../../page/zanguo/zanguo.yaml", "goto_baobei")
        from page.baobeiInZanguo.baobeiInZanguo import BaobeiInZanguo
        return BaobeiInZanguo(self.driver)
    # def getDescription(self):
    #     return self.steps("../../page/zanguo/zanguo.yaml", "getDescription")
    def goto_qiugouDetail(self):
        self.steps("../../page/zanguo/zanguo.yaml", "goto_qiugouDetail")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)

    def goto_backtoMine(self):
        self.steps("../../page/zanguo/zanguo.yaml", "goto_backtoMine")
        from page.mine.mine import Mine
        return Mine(self.driver)
    def clearinvalidXuqiu(self):
        return self.steps("../../page/zanguo/zanguo.yaml", "clearinvalidXuqiu")
