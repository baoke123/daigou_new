from page.basepage.basepage import BasePage



class EditQiugou(BasePage):
    def editQiugou(self, qiugouTitle):
        self._params["qiugouTitle"] = qiugouTitle
        self.steps("../../page/editQiugou/editQiugou.yaml", "editQiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)