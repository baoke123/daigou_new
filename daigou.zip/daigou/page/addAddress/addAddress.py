from page.basepage.basepage import BasePage



class AddAddress(BasePage):
    def addAddress(self, name, phoneNumber, detailAddress):
        self._params["name"] = name
        self._params["phoneNumber"] = phoneNumber
        self._params["detailAddress"] = detailAddress
        self.steps("../../page/addAddress/addAddress.yaml", "addAddress")
        from page.confirmOrder.confirmOrder import ConfirmOrder
        return ConfirmOrder(self.driver)

