from page.basepage.basepage import BasePage



class GoodsOrderList(BasePage):
    def goto_topayment(self):
        self.steps("../../page/goodsOrderList/goodsOrderList.yaml", "goto_topayment")
        from page.topayment.topayment import Topayment
        return Topayment(self.driver)
    def deleteOrder(self):
        return self.steps("../../page/goodsOrderList/goodsOrderList.yaml", "deleteOrder")
    def goto_OrderDetail(self):
        self.steps("../../page/goodsOrderList/goodsOrderList.yaml", "goto_OrderDetail")
        from page.orderDetail.orderDetail import OrderDetail
        return OrderDetail(self.driver)