from page.basepage.basepage import BasePage



class PublishQiugou(BasePage):
    def publishQiugou(self, qiugouDescription):
        self._params["qiugouDescription"] = qiugouDescription
        self.steps("../../page/publishQiugou/publishQiugou.yaml", "publishQiugou")
        from page.publishQiugouFinish.publishQiugouFinish import PublishQiugouFinish
        return PublishQiugouFinish(self.driver)
    # def goto_QiugouDetail(self):
    #     self.steps("../page/publishQiugou.yaml", "goto_qiugouDetail")
    #     return QiugouDetail(self.driver)
    # def backtoQiugou(self):
    #     return self.steps("../page/publishQiugou.yaml", "backtoQiugou")