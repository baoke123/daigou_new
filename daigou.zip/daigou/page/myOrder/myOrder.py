from page.basepage.basepage import BasePage
class MyOrder(BasePage):
    def getQiugouDescriptionInMyOrder(self):
        qiugouDescriptionInMyOrder = self.steps("../../page/myOrder/myOrder.yaml", "checkMyOrder")
        self._asserts["qiugouDescriptionInMyOrder"] = qiugouDescriptionInMyOrder
        return self
    def checkMyOrder(self):
        if(self._params["qiugouDescription"] == self._asserts["qiugouDescriptionInMyOrder"]):
            return self
    def goto_QiugouDetail(self):
        self.steps("../../page/myOrder/myOrder.yaml", "goto_QiugouDetail")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)
    def goto_swipedown_myorder(self):
        self.steps("../../page/myOrder/myOrder.yaml", "goto_swipedown_myorder")
        return self
    def checkInvalidXuqiu(self):
        return "该需求已失效" == self.steps("../../page/myOrder/myOrder.yaml", "checkInvalidXuqiu")