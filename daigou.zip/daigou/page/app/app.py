from appium import webdriver
from page.basepage.basepage import BasePage
from page.privatedOrder.privatedOrder import PrivatedOrder
class App(BasePage):
    # 启动app
    def start(self):
        if self.driver is None:
            caps = {}
            caps["platformName"] = "android"
            caps["platformVersion"] = "7"
            caps["appPackage"] = "com.daigou.purchaserapp"
            caps["appActivity"] = "com.daigou.purchaserapp.MainActivity"
            caps["deviceName"] = "127.0.0.1:62001"
            # caps["automationName"] = "UiAutomator2"
            caps["noReset"] = "true"
            self.driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", caps)
        else:
            self.driver.launch_app()
        self.driver.implicitly_wait(20)
        return self
    '''
    打开私人订制页面
    '''
    def goto_privatedOrder(self):
        self.steps("../../page/app/app.yaml", "goto_privatedOrder")
        return PrivatedOrder(self.driver)

    '''
    打开商城页面
    '''
    def goto_market(self):
        self.steps("../../page/app/app.yaml", "goto_market")
        from page.market.market import Market
        return Market(self.driver)
