from page.basepage.basepage import BasePage



class Market(BasePage):
    def goto_searchGoods(self):
        self.steps("../../page/market/market.yaml", "goto_searchGoods")
        from page.searchGoods.searchGoods import SearchGoods
        return SearchGoods(self.driver)
    def goto_swipeup_market(self):
        self.steps("../../page/market/market.yaml", "goto_swipeup_market")
        return self
    def goto_goodsDetail(self):
        self.steps("../../page/market/market.yaml", "goto_goodsDetail")
        from page.goodsDetail.goodsDetail import GoodsDetail
        return GoodsDetail(self.driver)
    def goto_personalcenter(self):
        self.steps("../../page/market/market.yaml", "goto_personalcenter")
        from page.personalCenter.personalCenter import PersonalCenter
        return PersonalCenter(self.driver)


