
from page.basepage.basepage import BasePage



class JiedanInMine(BasePage):
    def goto_myJiedan(self):
        self.steps("../../page/jiedanInMine/jiedanInMine.yaml", "goto_myJiedan")
        from page.myJiedan.myJiedan import MyJiedan
        return MyJiedan(self.driver)
    def goto_baobeiManage(self):
        self.steps("../../page/jiedanInMine/jiedanInMine.yaml", "goto_baobeiManage")
        from page.baobeiManage.baobeiManage import BaobeiManage
        return BaobeiManage(self.driver)




