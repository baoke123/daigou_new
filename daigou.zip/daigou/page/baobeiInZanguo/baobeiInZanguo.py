from appium.webdriver.common.mobileby import MobileBy
from page.basepage.basepage import BasePage
class BaobeiInZanguo(BasePage):
    def checkAndDeleteAllBaobei(self):
        locator_baobei = (MobileBy.ID, "com.daigou.purchaserapp:id/tvProductTitle")
        baobeiList = self.finds(locator_baobei)
        if len(baobeiList) > 0:
            self.steps("../../page/baobeiInZanguo/baobeiInZanguo.yaml", "goto_checkAndDeleteAllBaobei")
            return self
        else:
            return self

    def goto_privatedOrder(self):
        self.steps("../../page/baobeiInZanguo/baobeiInZanguo.yaml", "goto_privatedOrder")
        from page.privatedOrder.privatedOrder import PrivatedOrder
        return PrivatedOrder(self.driver)
    def checkBaobei(self):
        return self.steps("../../page/baobeiInZanguo/baobeiInZanguo.yaml", "checkBaobei")
    def clearinvalidBaobei(self):
        return self.steps("../../page/baobeiInZanguo/baobeiInZanguo.yaml", "clearinvalidBaobei")