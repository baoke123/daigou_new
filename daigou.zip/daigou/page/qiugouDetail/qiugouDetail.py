from appium.webdriver.common.mobileby import MobileBy

from page.basepage.basepage import BasePage



class QiugouDetail(BasePage):
    def goto_editQiugou(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_editQiugou")
        from page.editQiugou.editQiugou import EditQiugou
        return EditQiugou(self.driver)

    def goto_closeQiugou(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_closeQiugou")
        from page.closeQiugou.closeQiugou import CloseQiugou
        return CloseQiugou(self.driver)
    def goto_deleteQiugou(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_deleteQiugou")
        from page.deleteQiugou.deleteQiugou import DeleteQiugou
        return DeleteQiugou(self.driver)

    def dianzan(self):
        if(self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "dianzan")):
            return self
    def cancelDianzan(self):
        if(self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "cancelDianzan")):
            return self

    def savePicture(self):
        return self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "savePicture")
    def goto_checkViewnum(self):
        return self.checkViewnum()
    def goto_backtoQiugou(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_backtoQiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)
    def goto_swipeup_qiugouDetail(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_swipeup_qiugouDetail")
        return self

    def findoutModifyprice(self):
        while True:
            try:
                locator_modifyprice = (MobileBy.ID, "com.daigou.purchaserapp:id/tvCanSayPrice")
                self.set_webdriverWait_untilnot(locator_modifyprice, 1)
                self.swipeup_qiugouDetail()
            except Exception as e:
                print(e)
                break
        return self
    # 打开举报页面
    def goto_reportQiugou(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_reportQiugou")
        from page.reportQiugou.reportQiugou import ReportQiugou
        return ReportQiugou(self.driver)

    def goto_jiedan(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_jiedan")
        from page.jiedan.jiedan import Jiedan
        return Jiedan(self.driver)
    def cancelJiedan(self):
        return self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "cancelJiedan")

    def getDescriptionFromQiugouList(self):
        description1 = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getDescription")
        self._asserts["description1"] = description1
        return self
    def getDescriptionFromZanguo(self):
        description2 = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getDescription")
        self._asserts["description2"] = description2
        return self
    def getDescriptionFromMyJiedan(self):
        description3 = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getDescription")
        self._asserts["description3"] = description3
        return self

    def checkModifiedprice(self):
        priceInJiedan = self._params["price"]
        modifiedprice = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getPrice")
        return priceInJiedan == modifiedprice

    def checkQiugouInZanguo(self):
        return self._asserts["description1"] == self._asserts["description2"]
    def checkQiugouInMyJiedan(self):
        return self._asserts["description1"] == self._asserts["description3"]

    # 打开改价页面
    def goto_modifyprice(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_modifyprice")
        from page.modifyprice.modifyprice import Modifyprice
        return Modifyprice(self.driver)


    # 获取接单后，修改的商品价格
    def getModifiedprice(self):
        modifiedprice = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getModifiedprice")
        self._asserts["modifiedprice"] = modifiedprice
        return self
    # 检验接单后，修改后的商品价格在求购详情页面是否显示正确
    def checkModifiedpriceInQiugouDetail(self):
        return self._asserts["modifiedprice"] == self._params["price"]
    def getTopiclink(self):
        topiclinkInQiugouDetail = self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "getTopiclink")
        topiclinkInQiugouDetail = str(topiclinkInQiugouDetail).replace("  ", "")
        self._asserts["topiclinkInQiugouDetail"] = topiclinkInQiugouDetail
        return self

    def goto_topicpage(self):
        self.steps("../../page/qiugouDetail/qiugouDetail.yaml", "goto_topicpage")
        from page.topicpage.topicpage import Topicpage
        return Topicpage(self.driver)