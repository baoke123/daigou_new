from page.basepage.basepage import BasePage



class GoodsDetail(BasePage):
    def collect(self):
        if(self.steps("../../page/goodsDetail/goodsDetail.yaml", "collect")):
            return self
    def cancelCollect(self):
        if(self.steps("../../page/goodsDetail/goodsDetail.yaml", "cancelCollect")):
            return self
    def addtoShoppingbag(self):
        self.steps("../../page/goodsDetail/goodsDetail.yaml", "addtoShoppingbag")
        return self
    def goto_shoppingbag(self):
        self.steps("../../page/goodsDetail/goodsDetail.yaml", "goto_shoppingbag")
        from page.shoppingbag.shoppingbag import Shoppingbag
        return Shoppingbag(self.driver)
    def buyimmediately(self):
        self.steps("../../page/goodsDetail/goodsDetail.yaml", "buyimmediately")
        from page.confirmOrder.confirmOrder import ConfirmOrder
        return ConfirmOrder(self.driver)
    def goto_swipeup_goodsDetail(self):
        self.steps("../../page/goodsDetail/goodsDetail.yaml", "goto_swipeup_goodsDetail")
        return self
    def getGoodsDescriptionFromMarket(self):
        goodsDescriptionFromMarket = self.steps("../../page/goodsDetail/goodsDetail.yaml", "getGoodsDescriptionFromMarket")
        self._asserts["goodsDescriptionFromMarket"] = goodsDescriptionFromMarket
        return self
    def getGoodsDescriptionFromBrowserHistory(self):
        goodsDescriptionFromBrowserHistory = self.steps("../../page/goodsDetail/goodsDetail.yaml", "getGoodsDescriptionFromBrowserHistory")
        self._asserts["goodsDescriptionFromBrowserHistory"] = goodsDescriptionFromBrowserHistory
        return self
    def checkGoodsDescription(self):
        return self._asserts["goodsDescriptionFromMarket"] == self._asserts["goodsDescriptionFromBrowserHistory"]
    def backto_market(self):
        self.steps("../../page/goodsDetail/goodsDetail.yaml", "backto_market")
        from page.market.market import Market
        return Market(self.driver)
