from page.basepage.basepage import BasePage
class Modifyprice(BasePage):
    def modifyprice(self, price):
        self._params["price"] = price
        self.steps("../../page/modifyprice/modifyprice.yaml", "modifyprice")
        from page.myJiedan.myJiedan import MyJiedan
        return MyJiedan(self.driver)
    def modifypriceInQiugouDetail(self, price):
        self._params["price"] = price
        self.steps("../../page/modifyprice/modifyprice.yaml", "modifypriceInQiugouDetail")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)

