from page.basepage.basepage import BasePage



class SearchQiugou(BasePage):
    def searchQiugou(self, keyWord):
        self._params["keyWord"] = keyWord
        self.steps("../../page/searchQiugou/searchQiugou.yaml", "searchQiugou")
        return self
    def cancelSearchQiugou(self):
        self.steps("../../page/searchQiugou/searchQiugou.yaml", "cancelSearchQiugou")
        from page.qiugou.qiugou import Qiugou
        return Qiugou(self.driver)
    def deleteHistorySearchForQiugou(self):
        return self.steps("../../page/searchQiugou/searchQiugou.yaml", "deleteHistorySearchForQiugou")



