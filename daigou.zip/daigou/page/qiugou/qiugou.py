from page.basepage.basepage import BasePage



class Qiugou(BasePage):
    # 打开发布求购页面
    def goto_publishQiugou(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_publishQiugou")
        from page.publishQiugou.publishQiugou import PublishQiugou
        return PublishQiugou(self.driver)
    # 检验求购是否发布成功，并且显示在求购列表上方
    def checkQiugou(self):
        qiugouDescriptionFromPublishQiugou = self._params["qiugouDescription"]
        qiuggouDescriptionFromQigouDetai = self.steps("../../page/qiugou/qiugou.yaml", "checkQiugou")
        if(qiugouDescriptionFromPublishQiugou == qiuggouDescriptionFromQigouDetai):
            from page.qiugouDetail.qiugouDetail import QiugouDetail
            return QiugouDetail(self.driver)
    # 打开搜索求购页面
    def goto_searchQiugou(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_searchQiugou")
        from page.searchQiugou.searchQiugou import SearchQiugou
        return SearchQiugou(self.driver)
    # 打开我的页面
    def goto_mine(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_mine")
        from page.mine.mine import Mine
        return Mine(self.driver)
    # 打开求购详情页面
    def goto_qiugouDetail(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_qiugouDetail")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)
    # 向上滑动页面
    def goto_swipeup_qiugou(self):
        self.steps("../../page/qiugou/qiugou.yaml", "goto_swipeup_qiugou")
        return self






