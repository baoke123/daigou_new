from page.basepage.basepage import BasePage
class BaobeiManage(BasePage):
    def goto_editBaobei(self):
        self.steps("../../page/baobeiManage/baobeiManage.yaml", "goto_editBaobeiInBaobeiManage")
        from page.baobei.editBaobei import EditBaobei
        return EditBaobei(self.driver)
    def goto_undercarriageBaobei(self):
        self.steps("../../page/baobeiManage/baobeiManage.yaml", "goto_undercarriageBaobeiInBaobeiManage")
        from page.baobei.undercarriageBaobei import UndercarriageBaobei
        return UndercarriageBaobei(self.driver)
    def goto_undercarriageBaobeiList(self):
        self.steps("../../page/baobeiManage/baobeiManage.yaml", "goto_undercarriageBaobeiList")
        from page.undercarriageBaobeiList.undercarriageBaobeiList import UndercarriageBaobeiList
        return UndercarriageBaobeiList(self.driver)
    def goto_deleteBaobei(self):
        self.steps("../../page/baobeiManage/baobeiManage.yaml", "goto_deleteBaobei")
        from page.baobei.deleteBaobei import DeleteBaobei
        return DeleteBaobei(self.driver)