from page.basepage.basepage import BasePage


class ReportQiugou(BasePage):
    def reportQiugou(self, reason):
        self._params["reason"] = reason
        return self.steps("../../page/reportQiugou/reportQiugou.yaml", "reportQiugou")