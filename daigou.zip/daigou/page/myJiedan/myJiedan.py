from page.basepage.basepage import BasePage
class MyJiedan(BasePage):
    def goto_qiugouDetail(self):
        self.steps("../../page/myJiedan/myJiedana.yaml", "goto_qiugouDetail")
        from page.qiugouDetail.qiugouDetail import QiugouDetail
        return QiugouDetail(self.driver)
    def goto_modifyprice(self):
        self.steps("../../page/myJiedan/myJiedana.yaml", "goto_modifyprice")
        from page.modifyprice.modifyprice import Modifyprice
        return Modifyprice(self.driver)
    def cancelJiedan(self):
        self.steps("../../page/myJiedan/myJiedana.yaml", "cancelJiedan")
        return self
    def checkCancelJiedan(self):
        self._params["qiugouDescription"] = self._asserts["description1"]
        return self.steps("../../page/myJiedan/myJiedana.yaml", "checkCancelJiedan")
