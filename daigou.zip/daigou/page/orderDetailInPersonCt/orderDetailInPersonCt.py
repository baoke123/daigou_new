from page.basepage.basepage import BasePage


class OrderDetailInPersonCt(BasePage):
    def cancelOrder(self):
        return self.steps("../../page/orderDetailInPersonCt/orderDetailInPersonCt.yaml", "cancelOrder")
    def payimmediatelyInOrderDetail(self):
        self.steps("../../page/orderDetailInPersonCt/orderDetailInPersonCt.yaml", "payimmediatelyInOrderDetail")
        from page.wechat.wechat import Wechat
        return Wechat(self.driver)
    # def get_windowHandles(self):
    #     print(self.driver.window_handles)
    #     return self
