
from page.basepage.basepage import BasePage
class OrderDetail(BasePage):
    def closeKeyboard(self):
        self.back()
        return self
    def cancelOrder(self):
        self.steps("../../page/orderDetail/orderDetail.yaml", "cancelOrder")
        return self
    def payimmediately(self):
        self.steps("../../page/orderDetail/orderDetail.yaml", "payimmediately")
        from page.wechat.wechat import Wechat
        return Wechat(self.driver)
    def deleteOrder(self):
        return self.steps("../../page/orderDetail/orderDetail.yaml", "deleteOrder")
    def goto_baobeiDetail(self):
        self.steps("../../page/orderDetail/orderDetail.yaml", "goto_baobeiDetail")
        from page.baobei.baobeiDetail import BaobeiDetail
        return BaobeiDetail(self.driver)